import java.rmi.*;

public interface extends Remote{

public void Mess() throws Remote Excpetion;

}